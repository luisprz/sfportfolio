declare module "@salesforce/apex/PreciousMetalsController.getQuantityAvailable" {
  export default function getQuantityAvailable(): Promise<any>;
}
declare module "@salesforce/apex/PreciousMetalsController.avgPrice" {
  export default function avgPrice(): Promise<any>;
}
declare module "@salesforce/apex/PreciousMetalsController.getFrbTotalInvested" {
  export default function getFrbTotalInvested(): Promise<any>;
}
declare module "@salesforce/apex/PreciousMetalsController.getFrbTotalGain" {
  export default function getFrbTotalGain(): Promise<any>;
}
declare module "@salesforce/apex/PreciousMetalsController.getNearestEndDate" {
  export default function getNearestEndDate(): Promise<any>;
}
