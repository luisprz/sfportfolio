declare module "@salesforce/apex/PerformanceClass.getCryptoPerformance" {
  export default function getCryptoPerformance(): Promise<any>;
}
declare module "@salesforce/apex/PerformanceClass.getSilverPerformance" {
  export default function getSilverPerformance(): Promise<any>;
}
