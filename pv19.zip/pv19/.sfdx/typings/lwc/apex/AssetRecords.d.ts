declare module "@salesforce/apex/AssetRecords.getRecentRecords" {
  export default function getRecentRecords(param: {types: any}): Promise<any>;
}
declare module "@salesforce/apex/AssetRecords.getRecordTypes" {
  export default function getRecordTypes(): Promise<any>;
}
declare module "@salesforce/apex/AssetRecords.getRecordTypeIdByName" {
  export default function getRecordTypeIdByName(param: {Name: any}): Promise<any>;
}
