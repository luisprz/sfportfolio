import { LightningElement, api, track, wire } from 'lwc';
// import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import getFrbTotalInvested from '@salesforce/apex/PreciousMetalsController.getFrbTotalInvested';
import getNearestEndDate from '@salesforce/apex/PreciousMetalsController.getNearestEndDate';




export default class FrbWidget extends LightningElement {
    total = '';
    nearestEndDate;

    type = 'Fixed-Rate Bonds';

    connectedCallback() {
        getFrbTotalInvested().then((result) => {
            console.log(result);
            this.total = result;
    
        }).catch(e => {
            console.log(e);
        });

        getNearestEndDate().then((result) => {
            console.log(result);
            this.nearestEndDate = result;
    
        }).catch(e => {
            console.log(e);
        });
    
    }
}