import { LightningElement, api, track, wire } from 'lwc';
import getCryptoPerformance from '@salesforce/apex/PerformanceClass.getCryptoPerformance';

export default class PerformanceCryptoWidget extends LightningElement {
    cryptoPerformance = '';
    profitPercent;
    totalOriginalAmount = '';
    totalWithProfitAmount;
    isPositive = true;
    
    type = 'Performance';

    connectedCallback() { 
        getCryptoPerformance().then((result) => {
            console.log(result);
            this.cryptoPerformance = result;
            this.profitPercent = this.cryptoPerformance[0];
            this.totalOriginalAmount = this.cryptoPerformance[1];
            this.totalWithProfitAmount = this.totalOriginalAmount*(1+(this.profitPercent/100));
            
        }).catch(e => {
            console.log(e);
        });

    }

    renderedCallback(){
        if(this.profitPercent < 0){
            this.isPositive = false;

        }else{
            this.isPositive = true;
        }


    }
}