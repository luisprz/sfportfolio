import { LightningElement, wire, api } from 'lwc';
    import { NavigationMixin } from 'lightning/navigation';
      
    export default class NewRecordButton extends NavigationMixin(LightningElement) {   
        
        @api recordtypeid;
        navigateToNew() {
            
            if(this.recordtypeid){
                this[NavigationMixin.Navigate]({
                    type: 'standard__objectPage',
                    attributes: {
                        objectApiName: 'Asset__c',
                        actionName: 'new'
                    },
                    state: {
                        nooverride: '1',
                        recordTypeId: this.recordtypeid
                    }                  
                });
            }else{
                this[NavigationMixin.Navigate]({
                    type: 'standard__objectPage',
                    attributes: {
                        objectApiName: 'Asset__c',
                        actionName: 'new'
                    },
                    state: {
                        nooverride: '1',
                        useRecordTypeCheck:'1',
                        count : '0'
                    }                  
                });
            }
            
        }
    }