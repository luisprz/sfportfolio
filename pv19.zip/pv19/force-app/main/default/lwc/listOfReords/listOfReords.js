import { LightningElement, wire, track, api } from 'lwc';
import getRecentRecords from '@salesforce/apex/AssetRecords.getRecentRecords';
import getRecordTypeIdByName from '@salesforce/apex/AssetRecords.getRecordTypeIdByName';
const columns = [
    {
        label: 'Name',
        fieldName: 'nameUrl',
        type: 'url',
        typeAttributes: {label: { fieldName: 'Name' }, 
        target: '_blank'},
        sortable: true
    },
    {label : 'Detail', fieldName : 'Detail_name__c', type : 'text'},
    {label : 'Amount', fieldName : 'Transaction_Amount__c', type : 'currency', cellAttributes: { alignment: 'left' }},
    {label : 'Transaction type', fieldName : 'Transaction_type__c', type : 'text'},
    {label : 'Quantity', fieldName : 'Quantity__c', type : 'text'},
    {label : 'CreatedDate', fieldName : 'CreatedDate', type : 'date'}
]
export default class ListOfReords extends LightningElement {

    recordTypeID;
    @api columns = columns;
    @api recordtypesselected;
    @track records = [];
    @track error;
    
    @wire(getRecordTypeIdByName, {Name: '$recordtypesselected'}) 
    wiredRecordTypes(result){
        const { data, error } = result;
        if(data) {
            this.recordTypeID = data;
            this.error = null;
        }
        if(error) {
            this.error = error;
            this.recordTypeID = undefined;
        }
    }
    @wire(getRecentRecords, {types: '$recordtypesselected'}) 
    wiredRecords(result) {
        console.log("Test");
            console.log(this.recordTypeID);
            console.log("Test");
        const { data, error } = result;
        if(data) {
            let nameUrl;
            this.records = data.map(row => { 
                nameUrl = `/${row.Id}`;
                return {...row , nameUrl} 
            })
            this.error = null;
        }
        if(error) {
            this.error = error;
            this.records = [];
        }
    }
}