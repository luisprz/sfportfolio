import { LightningElement, api, track, wire } from 'lwc';
import getQuantityAvailable from '@salesforce/apex/PreciousMetalsController.getQuantityAvailable';
import avgPrice from '@salesforce/apex/PreciousMetalsController.avgPrice';
import getCryptoPerformance from '@salesforce/apex/PerformanceClass.getCryptoPerformance';

export default class CryptoWidget extends LightningElement {
    quantity = '';
    price = '';
    type = 'Crypto';
    profitPercent;
    profitAmount;
 

    connectedCallback() {
        getQuantityAvailable().then((result) => {
            console.log(result);
            this.quantity = result;

        }).catch(e => {
            console.log(e);
        });

        avgPrice().then((result) => {
            console.log(result);
            this.price = result;

        }).catch(e => {
            console.log(e);
        });

        getCryptoPerformance().then((result) => {
            console.log(result);
            this.getCryptoPerformance = result;
            this.profitPercent = this.getCryptoPerformance[0];
            this.profitAmount = this.getCryptoPerformance[1];
    
    
        }).catch(e => {
            console.log(e);
        });
    

        
    }

}