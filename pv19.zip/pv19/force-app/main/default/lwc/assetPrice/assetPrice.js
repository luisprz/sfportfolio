import { LightningElement, api, track, wire } from 'lwc';
// import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import getQuantityAvailable from '@salesforce/apex/PreciousMetalsController.getQuantityAvailable';
import avgPrice from '@salesforce/apex/PreciousMetalsController.avgPrice';
import getSilverPerformance from '@salesforce/apex/PerformanceClass.getSilverPerformance';


// import Transaction_Amount from '@salesforce/schema/Asset__c.Transaction_Amount__c';
// import Transaction_Type from '@salesforce/schema/Asset__c.Transaction_type__c';
// import Transaction__Asset_Quantity from '@salesforce/schema/Asset__c.Quantity__c';
// import Precious_Metal_Type from '@salesforce/schema/Asset__c.Type__c';

// const fields = [Transaction_Amount, Transaction_Type, Transaction__Asset_Quantity, Precious_Metal_Type];

export default class AssetPrice extends LightningElement {

    quantity = '';
    price = '';
    silverPerformance = '';
    profitPercent;
    profitAmount;
    //silverProfitBothValues = profitPercent + profitAmount;

    

    // value = Object.values(SilverPerformance);
    // valueOne = value[0];

    // performance() {
    // vals=[];
    // for(i=0;i<SilverPerformance.length;i++){
    //     vals.push(SilverPerformance[i]);
    // }
    // this.profitPercent = vals[0];
    // console.log('Profit percent:'+ this.profitPercent);
    // this.profitAmount = vals[1];
    // }


    @track dateTimeValue;
    expenseAmount() {
        
        var today = new Date();

        console.log("hi");
        

        var date = String(today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate());

        var time = String(today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds());

        var dateTime = date + ' ' + time;
        this.dateTimeValue = dateTime
        connectedCallback();

    }
    

    today() {
        this.expenseAmount();
        
    }


// @track QuantityAvailableX = '';

// @wire(getQuantityAvailable, {QuantityAvailableX: '$QuantityAvailableX'})
// Asset__c;



// @api recordId;

// @wire(getRecord, { recordId: '$recordId', fields })
// Asset__c;
// get quantityAvailable() {
// console.log(Transaction_Amount);
// return getFieldValue(this.Asset__c.data, Transaction_Amount);
// }

type = 'Silver';
//quantity = '16 oz';

connectedCallback() {
    getQuantityAvailable().then((result) => {
        console.log(result);
        this.quantity = result;

    }).catch(e => {
        console.log(e);
    });

    avgPrice().then((result) => {
        console.log(result);
        this.price = result;

    }).catch(e => {
        console.log(e);
    });

    getSilverPerformance().then((result) => {
        console.log(result);
        this.silverPerformance = result;
        this.profitPercent = this.silverPerformance[0];
        this.profitAmount = this.silverPerformance[1];


    }).catch(e => {
        console.log(e);
    });





}

   

 
}