import { LightningElement, api, track, wire } from 'lwc';
import getFrbTotalInvested from '@salesforce/apex/PreciousMetalsController.getFrbTotalInvested';
import getNearestEndDate from '@salesforce/apex/PreciousMetalsController.getNearestEndDate';
import getFrbTotalGain from '@salesforce/apex/PreciousMetalsController.getFrbTotalGain';


export default class PerformanceFrbWidget extends LightningElement {
    total = '';
    nearestEndDate;
    FrbTotalGain = '';
    type = 'Fixed-rate bonds';

    connectedCallback() { 

        getFrbTotalInvested().then((result) => {
            console.log(result);
            this.total = result;
    
        }).catch(e => {
            console.log(e);
        });

        getNearestEndDate().then((result) => {
            console.log(result);
            this.nearestEndDate = result;
    
        }).catch(e => {
            console.log(e);
        });

        getFrbTotalGain().then((result) => {
            console.log(result);
            this.FrbTotalGain = result;

        }).catch(e => {
            console.log(e);
        });

    }


}