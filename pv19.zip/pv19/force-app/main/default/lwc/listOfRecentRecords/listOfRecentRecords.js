import { LightningElement, wire, track } from 'lwc';
import getRecentRecords from '@salesforce/apex/AssetRecords.getRecentRecords';
import getRecordTypes from '@salesforce/apex/AssetRecords.getRecordTypes';
const columns = [
    {
        label: 'Name',
        fieldName: 'nameUrl',
        type: 'url',
        typeAttributes: {label: { fieldName: 'Name' }, 
        target: '_blank'},
        sortable: true
    },
    {label : 'Type', fieldName : 'Type__c', type : 'text'},
    {label : 'Detail', fieldName : 'Detail_name__c', type : 'text'},
    {label : 'Amount', fieldName : 'Transaction_Amount__c', type : 'currency', cellAttributes: { alignment: 'left' }},
    {label : 'Transaction type', fieldName : 'Transaction_type__c', type : 'text'},
    {label : 'Quantity', fieldName : 'Quantity__c', type : 'text'},
    {label : 'CreatedDate', fieldName : 'CreatedDate', type : 'date'}
]
export default class ListOfRecentRecords extends LightningElement {

    columns = columns;
    recordTypesSelected = [];
    mapRecordTypesAvailable;
    @track records = [];
    @track error;
    
    connectedCallback(){
        getRecordTypes()
        .then(result => {
            this.mapRecordTypesAvailable = result.map(type => {return {...this.mapRecordTypesAvailable, label:type, value: type}});
            this.recordTypesSelected = result;
            this.error = undefined;
        })
        .catch(error => {
            this.error = error;
            this.recordTypesAvailable = undefined;
        });
        

    }

    @wire(getRecentRecords, {types: '$recordTypesSelected'}) 
    wiredRecords(result) {
        const { data, error } = result;
        if(data) {
            let nameUrl;
            this.records = data.map(row => { 
                nameUrl = `/${row.Id}`;
                return {...row , nameUrl} 
            })
            this.error = null;
        }
        if(error) {
            this.error = error;
            this.records = [];
        }
    }

    handleChange(e) {
        this.recordTypesSelected = e.detail.value;
    }
    
    
}