import { LightningElement, api, track, wire } from 'lwc';
import getFrbTotalInvested from '@salesforce/apex/PreciousMetalsController.getFrbTotalInvested';
import getNearestEndDate from '@salesforce/apex/PreciousMetalsController.getNearestEndDate';

import getQuantityAvailable from '@salesforce/apex/PreciousMetalsController.getQuantityAvailable';
import avgPrice from '@salesforce/apex/PreciousMetalsController.avgPrice';
import getSilverPerformance from '@salesforce/apex/PerformanceClass.getSilverPerformance';

export default class PerformancePmWidget extends LightningElement {
    quantity = '';
    silverPerformance = '';
    profitPercent;
    totalOriginalAmount = '';
    totalWithProfitAmount;
    isPositive = true;
    
    type = 'Performance';

    connectedCallback() { 
        getSilverPerformance().then((result) => {
            console.log("data de silver"+result);
            this.silverPerformance = result;
            this.profitPercent = this.silverPerformance[0];
            this.totalOriginalAmount = this.silverPerformance[1];
            this.totalWithProfitAmount = this.totalOriginalAmount*(1+(this.profitPercent/100));


        }).catch(e => {
            console.log(e);
        });

        getQuantityAvailable().then((result) => {
            console.log(result);
            this.quantity = result;
            
    
        }).catch(e => {
            console.log(e);
        });

    }

    renderedCallback(){
        if(this.profitPercent < 0){
            this.isPositive = false;

        }else{
            this.isPositive = true;
        }


    }
}