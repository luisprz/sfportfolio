import { LightningElement } from 'lwc';

export default class ListOfCrypto extends LightningElement {
    recordType = "Crypto";
}