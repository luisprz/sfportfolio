import { LightningElement, track } from 'lwc';

export default class ProjectCommentViewModal extends LightningElement {
    @track isCommentOpen = false;

    openComment() {
        //to open comment box track value as true
        this.isCommentOpen = true;
    }

    closeComment() {
        this.isCommentOpen = false;
    }
}