import { LightningElement } from 'lwc';
const columns = [
    {
        label: 'Name',
        fieldName: 'nameUrl',
        type: 'url',
        typeAttributes: {label: { fieldName: 'Name' }, 
        target: '_blank'},
        sortable: true
    },
    {label : 'Detail', fieldName : 'Detail_name__c', type : 'text'},
    {label : 'Amount', fieldName : 'Transaction_Amount__c', type : 'currency', cellAttributes: { alignment: 'left' }},
    {label : 'Gain', fieldName : 'Gain__c', type : 'currency', cellAttributes: { alignment: 'left' }},
    {label : 'Start Date', fieldName : 'Start_date__c', type : 'date'},
    {label : 'Interest rate', fieldName : 'Rate__c', type : 'number'},
    {label : 'End Date', fieldName : 'End_date__c', type : 'date'},
    {label : 'CreatedDate', fieldName : 'CreatedDate', type : 'date'}
]
export default class ListOfBonds extends LightningElement {
    type = "Fixed-rate bonds";
    columns = columns;
}