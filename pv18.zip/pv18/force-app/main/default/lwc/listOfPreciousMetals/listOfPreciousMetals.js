import { LightningElement } from 'lwc';

export default class ListOfPreciousMetals extends LightningElement {}